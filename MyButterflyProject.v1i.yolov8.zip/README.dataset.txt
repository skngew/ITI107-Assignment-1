# MyButterflyProject > 2024-12-07 12:11am
https://universe.roboflow.com/skngew/mybutterflyproject

Provided by a Roboflow user
License: CC BY 4.0

