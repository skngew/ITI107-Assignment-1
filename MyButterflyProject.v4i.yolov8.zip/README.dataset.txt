# MyButterflyProject > 2024-12-15 8:28am
https://universe.roboflow.com/skngew/mybutterflyproject

Provided by a Roboflow user
License: CC BY 4.0

